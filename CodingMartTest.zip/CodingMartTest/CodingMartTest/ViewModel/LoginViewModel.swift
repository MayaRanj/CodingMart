//
//  LoginViewModel.swift
//  CodingMartTest
//
//  Created by Ranjith Karuvadiyil on 09/08/20.
//  Copyright © 2020 Maya Ranjith. All rights reserved.
//

import UIKit
import GoogleSignIn

protocol PEViewModelDelegate:class {
    func showNetworkError()
    func fetchedFacts()
    func showRequestError(_ error: String)
}

class LoginViewModel{
    var googleUser: GIDGoogleUser?
    weak var delegate: PEViewModelDelegate?

}

extension LoginViewModel{
        func fetchFactData(){
            if(!BaseManager.isReachable()){
                DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                    self.delegate?.showNetworkError()
                }
                return
            }
            PEFactmanger.getFactDetails { (response:PEDataModel?,error) in
                if error != nil{
                    self.delegate?.showRequestError(error?.localizedDescription ?? "")
                }else{
                    self.factDetails = []
                    self.factDetails?.append(contentsOf: (response?.factRows ?? []))
                    self.delegate?.fetchedFacts()
                }
            }
            
        }
        
}
