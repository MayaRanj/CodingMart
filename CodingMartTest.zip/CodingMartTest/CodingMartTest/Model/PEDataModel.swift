//
//  PEDataModel.swift
//  CodingMartTest
//
//  Created by Ranjith Karuvadiyil on 09/08/20.
//  Copyright © 2020 Maya Ranjith. All rights reserved.
//

import Foundation
//rates

struct PEDataModel: Codable {
    var rates: [String]?
    
    private enum PEDataCodingKeys: String,CodingKey{
        case rates = "rates"
    }
    
}

extension PEDataModel{
    init(from decoder:Decoder) throws{
        let dataInfo =  try decoder.container(keyedBy: PEDataCodingKeys.self)
        rates =  try dataInfo.decodeIfPresent(String.self, forKey: .rates)!
        
    }
}

