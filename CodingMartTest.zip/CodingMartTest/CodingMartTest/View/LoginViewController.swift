//
//  ViewController.swift
//  CodingMartTest
//
//  Created by Ranjith Karuvadiyil on 09/08/20.
//  Copyright © 2020 Maya Ranjith. All rights reserved.
//

import UIKit
import GoogleSignIn

class LoginViewController: UIViewController {
    var userName: String? = ""
    
    lazy  var viewModel: LoginViewModel = {
        let viewmodel = LoginViewModel()
        return viewmodel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func loginWithGoogleClicked(){
        GIDSignIn.sharedInstance().clientID = "901858282559-gasmibf09nosm982sjevqc7mv4bh3pk9.apps.googleusercontent.com"
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().presentingViewController = self

        GIDSignIn.sharedInstance().signIn()


        
        
    }
    
    
}

extension LoginViewController: GIDSignInDelegate{
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any]) -> Bool {
        return GIDSignIn.sharedInstance().handle(url)
    }
    
    func application(_ application: UIApplication,
                     open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return GIDSignIn.sharedInstance().handle(url)
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                print("The user has not signed in before or they have since signed out.")
            } else {
                print("\(error.localizedDescription)")
            }
            return
        }else{
            self.viewModel.googleUser = user
            self.userName = user.profile.name
            let story = UIStoryboard(name:"Main",bundle: nil)
            let vc = (story.instantiateViewController(identifier: "ConverterVC") as? ConverterViewController)!
            navigationController?.pushViewController(vc, animated: true)


            
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
      // Perform any operations when the user disconnects from app here.
      // ...
    }
}

