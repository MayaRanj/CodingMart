//
//  ConverterViewController.swift
//  CodingMartTest
//
//  Created by Ranjith Karuvadiyil on 09/08/20.
//  Copyright © 2020 Maya Ranjith. All rights reserved.
//

import UIKit
protocol ConverterDelegate: class {
    func didNextClicked(baseCurr: String,finalCurr:String)
}
class ConverterViewController: UIViewController {
    @IBOutlet weak var initailConvertView: UIView!
    @IBOutlet weak var finalConvertView: UIView!
    @IBOutlet weak var initailNextButton: UIButton!
    @IBOutlet weak var finalNextButton: UIButton!
    @IBOutlet weak var baseTextField: UITextField!
    @IBOutlet weak var finalTextField: UITextField!
    @IBOutlet weak var baseCurrencyLabel: UILabel!
    var baseCurrency: String?
    var convertedCurrency: String?
    weak var delegate: ConverterDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        initailConvertView.isHidden = false
        finalConvertView.isHidden = true
        baseTextField.returnKeyType = .done
        finalTextField.returnKeyType = .done

    }
    
    
    @IBAction func initailNextButtonClicked(){
        initailConvertView.isHidden =  true
        finalConvertView.isHidden = false
    }
    
    @IBAction func finalNextButtonClicked(){
        delegate?.didNextClicked(baseCurr: baseCurrency ?? "", finalCurr: convertedCurrency ?? "")
        let story = UIStoryboard(name:"Main",bundle: nil)
        let vc = (story.instantiateViewController(identifier: "HomeVC") as? HomeViewController)!
        navigationController?.pushViewController(vc, animated: true)

    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension ConverterViewController: UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {    //delegate method
        
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {  //delegate method
        return false
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
        if textField == baseTextField{
            baseCurrency = textField.text
        }else{
            convertedCurrency = textField.text
        }
        
        textField.resignFirstResponder()
        
        return true
    }
}
